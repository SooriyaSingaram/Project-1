angular.module('app', []);

angular
    .module('app')
    .controller('appCtrl', AppCtrl);

AppCtrl.$inject = ['$scope', '$http'];

function AppCtrl($scope, $http) {
    var vm = this;
    vm.handleError = function(response) {
        console.log(response.status + " - " + response.statusText + " - " + response.data);
    }
    /////////////////
    //add conference ////////
          function addConf() {
     var  reqData = {"channel_id":"doodleblue3",
                       "title":"zs"   } ;
                                        
        $http.post('/api/conferences', reqData).then(function(response){
           console.log(response.data)
        }, function(response){
            vm.handleError(response);
        });
    }
     function getAllConferences() {
        $http.get('/api/conferences').then(function(response){
            vm.confData = response.data;
console.log( vm.confData)      

}, function(response){
            vm.handleError(response);
        });
  }
    getAllConferences();
    //addConf()

    vm.del = del;
    function del(a){
        console.log(a)
     $http.post('/conferenceDelete', {'data':a}).then(function(response){
           console.log(response.data)
        }, function(response){
            vm.handleError(response);
        });
    }
  vm.getById = getById;
    function getById(a){
        console.log(a)
     $http.post('/conferenceGet', {'data':a}).then(function(response){
          vm.confById = response.data
        }, function(response){
            vm.handleError(response);
        });
    }
    vm.updateConf = updateConf;
    function updateConf(a){
$http.post('/conferenceUpdate', a).then(function(response){
          vm.confById = response.data
        }, function(response){
            vm.handleError(response);
        });
    }

}

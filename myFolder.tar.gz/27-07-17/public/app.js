angular.module('app', []);

angular
    .module('app')
    .controller('appCtrl', AppCtrl);

AppCtrl.$inject = ['$scope', '$http'];

function AppCtrl($scope, $http) {
    var vm = this;
    vm.signup = signup;
    vm.login = login;

    function login(a){
 if( /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(a.email) ){ 
     a.logintype = "email" 
  $http.post('/login', a).then(function(response){
        }, function(response){
            vm.handleError(response);
        });
  }  
    else if((/^\d+$/.test(a.email))  && a.email.length == 10){
             a.logintype = "mobile" 

$http.post('/login', a).then(function(response){
        }, function(response){
            vm.handleError(response);
        });
    }
else{   
    alert("plz enter valid email / mobile")

}

}  

    function signup(a){
           $http.post('/signup', a).then(function(response){
               alert("successfully added");
               vm.user={};;
               vm.terms_cont=null;
               vm.password_c = ""
        }, function(response){
            vm.handleError(response);
        });
    }
 

vm.read=true;
    vm.handleError = function(response) {
        console.log(response.status + " - " + response.statusText + " - " + response.data);
    }


    vm.editMode = false;


  

    vm.updateRecord = function() {
        $http.put('/records/' + vm.record._id, vm.record).then(function(response){
            vm.record = {};
            vm.getAllRecords();
            vm.editMode = false;
        }, function(response){
            vm.handleError(response);
        });
    }

vm.getCodes = function() {
        $http.get('/getCode').then(function(response){
            console.log("response  : "+ response);
            vm.codes=response.data;
        }, function(response){
            vm.handleError(response);
        })
    }

vm.check = check;    
    function check(){
    FB.getLoginStatus(function(response) {
  if (response.status === 'connected') {
    
      var user_data = {};


    console.log('Welcome!  Fetching your information.... ');
    FB.api('/me', function(response) {
console.log(response)
        console.log('Good to see you, ' + response.name + '.' + ' Email: ' + response.email + ' Facebook ID: ' + response.id);
    });


       user_data.uid = response.authResponse.userID;
     user_data.accessToken = response.authResponse.accessToken;
 $http.post('/getUserData', user_data).then(function(response){
         vm.user = response.data;
         console.log(vm.user)
        }, function(response){
            vm.handleError(response);
        });

  }
  else {
        vm.fb_button = true;
    FB.login();
  }
});

}
  vm.user= {}
 function onSignIn(googleUser) {
   
    var profile = googleUser.getBasicProfile();
    console.log('Name: ' + profile.getName());
    var name = profile.getName().split(" ");
     vm.user.first_name = name[0];
     vm.user.last_name = name[1];
    vm.user.email = profile.getEmail();
  
   }

//vm.signupGmail = signupGmail;
// function signupGmail(){
//    if(vm.gData.email){
//        console.log("values")
//    }
//     else{
//       vm.gmailSign=true;
//          vm.user=  angular.copy(vm.gData)
//     }
//    vm.user=  angular.copy(vm.gData)
   
// }
// signupGmail()
  window.onSignIn = onSignIn;
   vm.getCodes()
    vm.cancelEdit = function() {
        vm.editMode = false;
        vm.record = {};
        vm.getAllRecords();
    }
    //////////////
      function  getProfileData() { // Use the API call wrapper to request the member's basic profile data
        IN.API.Profile("me").fields("id,firstName,lastName,email-address,picture-urls::(original),public-profile-url,location:(name)").result(function (me) {
            var profile = me.values[0];
            var id = profile.id;
            var firstName = profile.firstName;
            var lastName = profile.lastName;
            var emailAddress = profile.emailAddress;
            var pictureUrl = profile.pictureUrls.values[0];
            var profileUrl = profile.publicProfileUrl;
            var country = profile.location.name;
        });
    }


    /////////////////
    //add conference ////////
          function addConf() {
     var  reqData = {"channel_id":"doodleblue3",
                       "title":"zs"   } ;
                                        
        $http.post('/api/conferences', reqData).then(function(response){
           console.log(response.data)
        }, function(response){
            vm.handleError(response);
        });
    }
     function getAllConferences() {
        $http.get('/api/conferences').then(function(response){
            vm.confData = response.data.conferences;
console.log( vm.confData)      

}, function(response){
            vm.handleError(response);
        });
  }
    getAllConferences();
   // addConf()

    vm.del = del;
    function del(a){
        console.log(a)
     $http.post('/conferenceDelete', {'data':a}).then(function(response){
           console.log(response.data)
        }, function(response){
            vm.handleError(response);
        });
    }
    ///////////////////////////////////////////////
  $scope.myMessage;
 
   var myInt = setInterval(function() {
     if (document.getElementById('myMessage').value !== '') {
       $scope.myMessage = document.getElementById('myMessage').value;
       console.log($scope.myMessage)
      var user = $scope.myMessage.split("/");
     vm.user.first_name = user[0];
     vm.user.last_name = user[1];
       $scope.$apply();
       clearInterval(myInt);
     }
   }, 150);

}

var express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    MongoClient = require('mongodb').MongoClient,
    engines = require('consolidate'),
    assert = require('assert'),
    ObjectId = require('mongodb').ObjectID,
    url = 'mongodb://localhost:27017/userlist',
     http = require("https");
    var bcrypt = require('bcryptjs');
    var _ = require('lodash');
var request = require('request');

var Conference = require('./server/models/conference');

app.use(express.static(__dirname + "/public"));

//**********************************************
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.engine('html', engines.nunjucks);
app.set('view engine', 'html');
app.set('views', __dirname + '/views');

function errorHandler(err, req, res, next) {
    console.error(err.message);
    console.error(err.stack);
    res.status(500).render("error_template", { error: err});
}

MongoClient.connect(process.env.MONGODB_URI || url,function(err, db){
    assert.equal(null, err);
    console.log('Successfully connected to MongoDB.');

    var records_collection = db.collection('records');
     var conference = db.collection('conference');
    var user = db.collection('users');

       
     app.get('/api/conferences', function(req, res, next) {
        conference.find({}).toArray(function(err, records){
            if(err) throw err;

            if(records.length < 1) {
                
            }

            // console.log(records);
            res.json(records);
        });
  })


    app.post('/conferenceDelete', function(reqs, resp, next){

var options = {
  "method": "DELETE",
  "hostname": "www.bigmarker.com",
  "port": null,
  "path": "/api/v1/conferences/"+reqs.body.data,
  "headers": {
    "api-key": "8c1708b7ecf542da8161",
    "cache-control": "no-cache",
    "postman-token": "f938990f-7dfe-fed4-4262-a1c1a38b1d8d"
  }
};

var req = http.request(options, function (res) {
  var chunks = [];

  res.on("data", function (chunk) {
    chunks.push(chunk);
  });

  res.on("end", function () {
    var body = Buffer.concat(chunks);
    console.log("deleted")
    var a = body.toString();
    console.log(body.toString());
conference.deleteOne({'id': reqs.body.data}, function(err, results){
         //   console.log(results);
            resp.json(results);
        });


  });
});

req.end();
    });

    app.post('/conferenceGet', function(reqs, resp, next){
conference.findOne( {'id': reqs.body.data},
function(err, results){
                resp.json(results);
        });

    });

    // app.put('/records/:id', function(req, res, next){
    //     var id = req.params.id;
    //     records_collection.updateOne(
    //         {'_id': new ObjectId(id)},
    //         { $set: {
    //             'name' : req.body.name,
    //             'email': req.body.email,
    //             'phone': req.body.phone
    //             }
    //         }, function(err, results){
    //             console.log(results);
    //             res.json(results);
    //     });
    // });
   

    ///////conference

    app.post('/api/conferences', function(req, resp, next) {
         var confD = new Conference(req.body) ;
   var confData = JSON.stringify(confD);
var options = {
  "method": "POST",
  "hostname": "www.bigmarker.com",
  "port": null,
  "path": "/api/v1/conferences",
  "headers": {
    "api-key": "8c1708b7ecf542da8161"   
  }
};

var req = http.request(options, function (res) {
  var chunks = [];

  res.on("data", function (chunk) {
    chunks.push(chunk);
  });

  res.on("end", function () {
    var body = Buffer.concat(chunks);
    console.log(body.toString());
     var a =JSON.parse(body.toString()) ;
if(a.id){
    conference.insert(a, function(err, doc) {
            if(err) throw err;
            console.log(doc);
            resp.json(doc);
        });
}
  });
});
 req.write(confData);
 console.log(confData)
req.end();
});
/////////////////////////////////////////
    app.post('/conferenceUpdate', function(req, resp, next) {
      var http = require("https");

var options = {
  "method": "PUT",
  "hostname": "www.bigmarker.com",
  "port": null,
  "path": "/api/v1/conferences/4de87e1e924c",
  "headers": {
    "api-key": "8c1708b7ecf542da8161",
    "content-type": "application/json",
    "cache-control": "no-cache",
    "postman-token": "a9b20754-95fa-e441-553b-75d3fc6cad82"
  }
};

var req = http.request(options, function (res) {
  var chunks = [];

  res.on("data", function (chunk) {
    chunks.push(chunk);
  });

  res.on("end", function () {
    var body = Buffer.concat(chunks);
    console.log(body.toString());
  });
});

req.write(JSON.stringify({ id: '4de87e1e924c',
  title: 's',
  max_attendance: 100,
  purpose: null,
  duration: 60,
  conference_address: 'https://www.bigmarker.com/doodleblue3/zs60',
  channel_id: 'doodleblue3',
  dial_in_information: 
   { dial_in_number: 'Dial-in is disabled.',
     dial_in_id: '',
     dial_in_passcode: '' },
  presenters: 
   [ { presenter_id: 'd51c9d225083',
       member_id: '296409bfafbd',
       conference_id: '4de87e1e924c',
       first_name: 'surya ',
       last_name: null,
       email: 'surya.doodleblue@gmail.com',
       presenter_url: 'https://www.bigmarker.com/doodleblue3/zs60?bmid=296409bfafbd',
       title: null,
       bio: null,
       can_manage: true,
       is_moderator: true } ],
  enable_knock_to_enter: false }));
req.end();
//  var updatedData = JSON.stringify(req.body);
// var options = {
//   "method": "PUT",
//   "hostname": "www.bigmarker.com",
//   "port": null,
//   "path": "/api/v1/conferences/"+req.body.id,
//   "headers": {
//     "api-key": "8c1708b7ecf542da8161",
//     "content-type": "application/json",
//     "cache-control": "no-cache",
//     "postman-token": "0b6c3901-36da-b2a2-13d1-21683a240565"
//   }
// };

// var req = http.request(options, function (res) {
//   var chunks = [];

//   res.on("data", function (chunk) {
//     chunks.push(chunk);
//   });

//   res.on("end", function () {
//     var body = Buffer.concat(chunks);
//     console.log(body.toString());
//     resp.send(body.toString())
//   });
// });

// req.write(JSON.stringify(updatedData));
// req.end();
    })
///////////////////////////////////////

    app.use(errorHandler);
    var server = app.listen(process.env.PORT || 8080, function() {
        var port = server.address().port;
        console.log('Express server listening on port %s.', port);
    })
})


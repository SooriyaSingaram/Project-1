var mongoose = require('mongoose');
var userSchema =  new Schema({
    first_name: {
        type: String
    },
   last_name: {
        type: String
    },
    email: {
        type: String
    },
    code: {
        type: String
    },
    mobile:{
        type: Number
    },
    payment:{
        type: Boolean
    },
    password:{
        type: String
    }

});
module.exports = mongoose.model('user', userSchema);
module.exports.schema = userSchema;

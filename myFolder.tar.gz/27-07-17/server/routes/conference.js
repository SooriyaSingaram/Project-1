var Conference = require('../models/conference'),
    express = require('express'),
    http = require("https"),

    router = express.Router();

//configure routes
router.route('/conferences')
    .get(getConference)
    .post(addConference);

router.route('/conferences/:id')
    .put(updateConference)
    .get(getConferenceById)
    .delete(deleteConference);

//Get the All the Conference Details  
function getConference(req, res) {
    Conference.find({}, function(err, conferences) {Ron
        if (err)
            res.send(err);

        res.json(conferences);
    });
}
//Create the New Conference
function addConference(requ, resp,next) {
   var confD = new Conference(requ.body) ;
   var confData = JSON.stringify(confD);
var options = {
  "method": "POST",
  "hostname": "www.bigmarker.com",
  "port": null,
  "path": "/api/v1/conferences",
  "headers": {
    "api-key": "8c1708b7ecf542da8161"   
  }
};

var req = http.request(options, function (res) {
  var chunks = [];

  res.on("data", function (chunk) {
    chunks.push(chunk);
  });

  res.on("end", function () {
    var body = Buffer.concat(chunks);
  //  console.log(body.toString())
        var a =JSON.parse(body.toString()) ;
if(a.id){

}
        resp.send(body.toString());
  });
});


 req.write(confData);
 //console.log(confData)
req.end();

}

//Update the Conference Details for Particular Id
function updateConference(req, res) {
    Conference.findOne({
            _id: req.params.id
        },
        function(err, conferences) {
            if (err)
                res.send(err);

            for (prop in req.body) {
                conferences[prop] = req.body[prop];
            }

            // save conferences details
            conferences.save(function(err) {
                if (err)
                    res.send(err);

                res.json({
                    message: 'Successfully Updated!'
                });
            });

        });
}
//Get the Conference Details for Particular Id
function getConferenceById(req, res) {
    Conference.findOne({
            _id: req.params.id
        },
        function(err, conferences) {
            if (err)
                res.send(err);
            res.json(conferences);
        });
}
//Delete the Particular Conference
function deleteConference(req, res) {

    Conference.remove({
        _id: req.params.id
    }, function(err, conferences) {
        if (err)
            res.send(err);
        res.json({
            message: 'Successfully Deleted'
        });
    });

}


module.exports = router;
var express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    MongoClient = require('mongodb').MongoClient,
    engines = require('consolidate'),
    assert = require('assert'),
    ObjectId = require('mongodb').ObjectID,
    url = 'mongodb://localhost:27017/userlist',
     http = require("https");
    var bcrypt = require('bcryptjs');
    var _ = require('lodash');
var request = require('request');

var Conference = require('./server/models/conference');

app.use(express.static(__dirname + "/public"));


//// get Country Code from json
app.get('/getCode',function(req,resp){
var http = require("https");

var options = {
  "method": "GET",
  "hostname": "gist.githubusercontent.com",
  "port": null,
  "path": "/Goles/3196253/raw/9ca4e7e62ea5ad935bb3580dc0a07d9df033b451/CountryCodes.json",
  "headers": {
    "cache-control": "no-cache",
    "postman-token": "fdc3460c-6e70-35c6-1751-35ec4f4e3fbf"
  }
};

var req = http.request(options, function (res) {
  var chunks = [];

  res.on("data", function (chunk) {
    chunks.push(chunk);
  });

  res.on("end", function () {
    var body = Buffer.concat(chunks);
   // console.log(body.toString());
    resp.send(body)
  });
});

req.end();

})

//**********************************************
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.engine('html', engines.nunjucks);
app.set('view engine', 'html');
app.set('views', __dirname + '/views');

function errorHandler(err, req, res, next) {
    console.error(err.message);
    console.error(err.stack);
    res.status(500).render("error_template", { error: err});
}

MongoClient.connect(process.env.MONGODB_URI || url,function(err, db){
    assert.equal(null, err);
    console.log('Successfully connected to MongoDB.');

    var records_collection = db.collection('records');
     var conference = db.collection('conference');
    var user = db.collection('users');

    app.get('/records', function(req, res, next) {
        // console.log("Received get /records request");
        records_collection.find({}).toArray(function(err, records){
            if(err) throw err;

            if(records.length < 1) {
                console.log("No records found.");
            }

            // console.log(records);
            res.json(records);
        });
    });

    app.post('/records', function(req, res, next){
        console.log(req.body);
        records_collection.insert(req.body, function(err, doc) {
            if(err) throw err;
            //console.log(doc);
            res.json(doc);
        });
    });
     app.post('/signup', function(req, res, next){
         console.log(req.body)
         var userParam = req.body;
       var userdata = _.omit(userParam, 'password');
userdata.payment=false;
        // add hashed password to user object
        userdata.hash = bcrypt.hashSync(userParam.password, 10);
        user.insert(userdata, function(err, doc) {
            if(err) throw err;
            console.log(doc);
            res.json(doc);
        });
    });

      app.post('/', function(req, res, next){
        
    console.log(req.body)
    });


         app.post('/login', function(req, res, next){
        var logindetail = req.body.email;
       var hash = bcrypt.hashSync(req.body.password, 10);
        console.log(hash)
        console.log(req.body.logintype)
        if(req.body.logintype == 'mobile'){
console.log("mobile validation");

user.findOne({'mobile': logindetail}, function(err, results){
            console.log(results);
            res.json(results);
        });
        
    //     user.findOne({mobile: req.body.email}).toArray(function(err, records){
        
    //    console,log(records);


    // });
        }
else{
    console.log("email validation")

   user.findOne({'email': logindetail,'hash':hash}, function(err, results){
            console.log(results);
            res.json(results);
        });

}
         });
    app.delete('/records/:id', function(req, res, next){
        var id = req.params.id;
        console.log("delete " + id);
        records_collection.deleteOne({'_id': new ObjectId(id)}, function(err, results){
            console.log(results);
            res.json(results);
        });
    });

    app.put('/records/:id', function(req, res, next){
        var id = req.params.id;
        records_collection.updateOne(
            {'_id': new ObjectId(id)},
            { $set: {
                'name' : req.body.name,
                'email': req.body.email,
                'phone': req.body.phone
                }
            }, function(err, results){
                console.log(results);
                res.json(results);
        });
    });
      app.post('/getUserData', function(req, res, next){
   request(' https://graph.facebook.com/v2.6/'+req.body.uid+'?fields=first_name,last_name,email,gender&access_token='+req.body.accessToken, function (error, response, body) {
 //console.log(body)
 
    var signupDetail = JSON.parse(body);

res.json(signupDetail);

});
    });
    // var conference = require('./server/routes/conference'); 
    
    // app.use('/api', conference);

    ///////conference

    app.post('/api/conferences', function(req, resp, next) {
         var confD = new Conference(req.body) ;
   var confData = JSON.stringify(confD);
var options = {
  "method": "POST",
  "hostname": "www.bigmarker.com",
  "port": null,
  "path": "/api/v1/conferences",
  "headers": {
    "api-key": "8c1708b7ecf542da8161"   
  }
};

var req = http.request(options, function (res) {
  var chunks = [];

  res.on("data", function (chunk) {
    chunks.push(chunk);
  });

  res.on("end", function () {
    var body = Buffer.concat(chunks);
    console.log(body.toString());
     var a =JSON.parse(body.toString()) ;
if(a.id){
    conference.insert(a, function(err, doc) {
            if(err) throw err;
            console.log(doc);
            resp.json(doc);
        });
}
  });
});
 req.write(confData);
 console.log(confData)
req.end();
});
///////////////////////////////////////

    app.use(errorHandler);
    var server = app.listen(process.env.PORT || 8080, function() {
        var port = server.address().port;
        console.log('Express server listening on port %s.', port);
    })
})


var express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    MongoClient = require('mongodb').MongoClient,
    engines = require('consolidate'),
    assert = require('assert'),
    ObjectId = require('mongodb').ObjectID,
    url = 'mongodb://localhost:27017/userlist',
    http = require("https");
var google = require('googleapis');
var _ = require('lodash');
var request = require('request');
var appStoreReviewsModule = require('app-store-reviews');

var stripe = require("stripe")(
    "sk_test_BQokikJOvBiI2HlWgH4olfQ2"
);

app.use(express.static(__dirname + "/public"));

app.get('/stripe', function (req, res) {

    stripe.balance.listTransactions({ limit: 100 }, function (err, transactions) {
        res.send(transactions);
    });
})
app.get('/stripePayout', function (req, res) {

    stripe.payouts.list(
        { limit: 100 },
        function (err, payouts) {
            res.send(payouts);
        }
    );

});
app.get('/stripeCharge', function (req, res) {
    stripe.charges.list(
        { limit: 100 },
        function (err, charges) {
            res.send(charges)
        }
    );
})

// app.get('/appleData', function (req, res) {
//     var appStoreReviews = new appStoreReviewsModule();
//     appStoreReviews.on('review', function (review) {
//         res.send(review);
//     });
//     appStoreReviews.getReviews('1250065306', 'us', 1);
// })


var store = require('app-store-scraper');
app.get('/appRateReview', function (req, res) {
    store.app({ appId: 'com.drreddy.sidekick' }).then(function (data) {
        res.send(data);
    }).catch(function (err) {

        res.status(404).send({ Error: "App not found" });
        console.log(err)
    });
})
// *****************************************************************************************
// import google from 'googleapis';

var key = require('config.json')('./client_secret.json');

const VIEW_ID = 'ga:158582978';
var access_token = ""
console.log(key.client_email);
app.get('/ga', function (req, res) {
    let jwtClient = new google.auth.JWT(
        key.client_email, null, key.private_key,
        ['https://www.googleapis.com/auth/analytics.readonly', 'https://www.googleapis.com/auth/analytics.readonly'], null);
    jwtClient.authorize(function (err, tokens) {
        // console.log(tokens);
        if (err) {
            console.log(err);
            return;
        }
        else {
            access_token = tokens.access_token;
            let analytics = google.analytics('v3');
            queryData(analytics);
        }
    });

    function queryData(analytics) {
        console.log(access_token);
        analytics.data.ga.get({
            // 'auth': jwtClient,
            // 'grant_type' : "authorization_code",
            'access_token': access_token,
            'ids': VIEW_ID,
            'metrics': 'ga:adClicks,ga:costPerConversion',
            // 'metrics': 'ga:adClicks',
            // 'metrics': 'ga:goalXXConversionRate',
            // 'metrics': 'ga:costPerConversion',
            // 'dimensions' : 'ga:sessions',
            'start-date': '30daysAgo',
            'end-date': 'yesterday'
        }, function (err, response) {
            if (err) {
                console.log(err);
                return;
            }
           // console.log(JSON.stringify(response, null, 4));
            res.send(response);
        });
    }
});


//************************************************************************************************ */
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.engine('html', engines.nunjucks);
app.set('view engine', 'html');
app.set('views', __dirname + '/views');

function errorHandler(err, req, res, next) {
    console.error(err.message);
    console.error(err.stack);
    res.status(500).render("error_template", { error: err });
}

MongoClient.connect(process.env.MONGODB_URI || url, function (err, db) {
    assert.equal(null, err);
    console.log('Successfully connected to MongoDB.');
    app.use(errorHandler);
    var server = app.listen(process.env.PORT || 7777, function () {
        var port = server.address().port;
        console.log('Express server listening on port %s.', port);
    })
})

// https://api-metrics.flurry.com/public/v1/data/appUsage/day?metrics=sessions,activeDevices,newDevices&dateTime=2016-06-01/2016-08-01&filters=app|apiKey-in[3WD7Q8329867K7MY6RNS]

// flurry api:M3NHW5S52DWJDFVC9Y86
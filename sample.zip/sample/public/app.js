angular.module('app', []);

angular
    .module('app')
    .controller('appCtrl', AppCtrl);

AppCtrl.$inject = ['$scope', '$http'];

function AppCtrl($scope, $http) {
    var vm = this;

    vm.myFunc = myFunc;
    vm.appStore = appStore;
    function myFunc() {

        $http.get('/stripe').then(function (response) {
            $scope.totalBal = 0;
            var balanceArray = response.data.data;

            angular.forEach(balanceArray, function (data) {
                $scope.totalBal += data.amount
            })
        });
        $http.get('/stripePayout').then(function (response) {
            $scope.totalPay = 0;
            var payoutArray = response.data.data;

            angular.forEach(payoutArray, function (data) {
                $scope.totalPay += data.amount
            })
        });

    }
    function appStore() {
        $http.get('/appRateReview').then(success, error);
        function success(res) {
            console.log(res)
        }
        function error(e) {
            console.log(e)
        }
    }
    function gaApi() {
        $http.get('/ga').then(function (response) {
            $scope.analyticsGoogle = response.data.totalsForAllResults;
            $scope.googleClick =  $scope.analyticsGoogle["ga:adClicks"];
$scope.googleConversion =  $scope.analyticsGoogle["ga:costPerConversion"];
            
        });
    }
    function customer() {
        $scope.costUser = 0;
        $http.get('/stripeCharge').then(function (response) {
            var data = response.data.data;
            angular.forEach(data, function (user) {
                $scope.costUser += user.amount;

            })
            console.log($scope.costUser)
        });

    }
    gaApi()
    customer()
    appStore()
    myFunc()


}

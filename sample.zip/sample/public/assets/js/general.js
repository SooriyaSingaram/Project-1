$(document).ready(function() {





/*index page*---------------*/
$('a#detail-a').click(function() {
$(this).parent().parent().parent().parent().parent().parent().find('.q-detail').fadeIn('normal');
$(this).parent().parent().parent().parent().parent().parent().find('.q-analytics-chart').hide();
$(this).parent().parent().parent().parent().parent().parent().find('a#detail-a').addClass('selected');
$(this).parent().parent().parent().parent().parent().parent().find('a#analytics-a').removeClass('selected');
$(this).parent().parent().parent().parent().parent().parent().parent().parent().find('tr.first').addClass('selected');
return false;



});

$('a#analytics-a').click(function() {
$(this).parent().parent().parent().parent().parent().parent().find('.q-detail').hide();
$(this).parent().parent().parent().parent().parent().parent().find('.q-analytics-chart').fadeIn('normal');
$(this).parent().parent().parent().parent().parent().parent().find('a#detail-a').removeClass('selected');
$(this).parent().parent().parent().parent().parent().parent().find('a#analytics-a').addClass('selected');
$(this).parent().parent().parent().parent().parent().parent().parent().parent().find('tr.first').removeClass('selected');
return false;
});
$('a#add-category-a').click(function() {

	$('.add-new-form').slideToggle('fast');
return false;
});

$('a#add-customer-a').click(function() {

	$('.add-customer-form').fadeIn('fast');
	$('.hide-table').hide();
return false;
});

$('a#close-add-customer-a').click(function() {

	$('.add-customer-form').hide();
	$('.hide-table').fadeIn('fast');
return false;
});

$('a.analytics-sub-a').click(function() {

	$('li.sub-menu').slideToggle('fast');
return false;
});




$('a#view-details-user-a').click(function() {
  $('.one-customer-detail-box').fadeIn();
	$('.customer-detail-analytics-box').hide();
return false;
});


$('a#view-product-a').click(function() {
  $('.products-on-viewd-sub-catalog').fadeIn();
	$('.list-user-viewed-subcatalog, .one-visit').hide();
return false;
});


$('a#hide-view-all-product-a').click(function() {
  $('.products-on-viewd-sub-catalog').hide();
	$('.list-user-viewed-subcatalog, .one-visit').fadeIn();
return false;
});



$('a#hide-user-viewd-list-a').click(function() {
  $('.one-customer-detail-box').hide();
	$('.customer-detail-analytics-box').fadeIn();
return false;
});


$('a#mob-nav-a').click(function() {
  $('.mobile-nav').slideToggle('fast');
  return false;
});







});



$(document).ready(function(){ 
  /*creating click event for each tab menu*/
  $(document.body).on("click",".tab-a",function(){        
    $(".form-step").removeClass('active-form');
    /*adding the active class for the current selected tab*/
     $(".form-step[data-id='"+$(this).attr('data-id')+"']").addClass("active-form");
    
     /*adding the active class for the current selected tab menu*/
     $(this).parent().find(".tab-a .circle").addClass('circle-active');
  });
});


// SIde Modal Script Starts

$(document).ready(function(){
  $('#open-modal ').click(function(){
    $('.rsa-modal-wrap').fadeIn('normal');
      $('.rsa-modal-view').css({'transform':' translateX(0)'})
    return false;
  });

  $('a#rsa-view-close-a ,.rsa-modal-wrap').click(function(){
    $('.rsa-modal-wrap').fadeOut('normal');
      $('.rsa-modal-view').css({'transform':' translateX(100%)'})
    return false;
  });  
});

// Side modal Ends


// $(document).ready(function(){
//   $('a#open-hub-modal').click(function(){
//       $('.rsa-modal-hub-wrap').fadeIn('normal');
//         $('.rsa-modal-hub-view').css({'transform':' translateX(0)'})
//       return false;
//     });

//     $('a#rsa-view-close-a ,.rsa-modal-hub-wrap').click(function(){
//       $('.rsa-modal-hub-wrap').fadeOut('normal');
//         $('.rsa-modal-hub-view').css({'transform':' translateX(100%)'})
//       return false;
//     });
// }); 

// $(document).ready(function(){
//  $('a#test').click(function(){
//    alert();
//    window.location='http://google.com';
//    $('.rsa-modal-view').css({"display":"none !important"});
//  });
// });
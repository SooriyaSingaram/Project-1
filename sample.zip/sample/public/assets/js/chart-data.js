// var randomScalingFactor = function(){ return Math.round(Math.random()*90)};

	var lineChartData = {
			labels : ["JAN","FEB","MAR","APR","MAY","JUNE"],
			datasets : [
				{
					label: "My Second dataset",
					fillColor : "transparent",
					strokeColor : "rgba(48, 164, 255, 1)",
					pointColor : "rgba(48, 164, 255, 1)",
					data : [10, 5, 20, 15, 5, 25]
				}
			]

		}

window.onload = function(){
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
		responsive: true
	});


};

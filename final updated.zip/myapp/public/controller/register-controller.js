(function () {

    'use strict';

    angular
        .module('app')
        .controller('registerController', RegisterController);

    RegisterController.$inject = ['dataService', '$http', '$state', '$scope'];

    /**
     * @memberof module:register
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function RegisterController(dataService, $http, $state, $scope) {

        var self = this,
            data = {},
            url = "/register";
        self.check = check;


        self.addRegister = addRegister;

        // Handles the error while getting false function
        function errorHandler(e) {
            console.log(e.toString());
        }
        /**
         * Add the registers details using data service passing the URL.
         * Its first validate the registers details and allow to add data.
         * On success call getting all registers details in a summary list.
         * @param customerType
         */
        function addRegister(register) {
      
            dataService.saveData(url, register).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
            function successHandler(responseData) {
                alert(responseData.message);
                $state.go('payment')

            }

        }

        ///////Facebook login ///////////        
        function check() {
            FB.getLoginStatus(function (response) {
                if (response.status === 'connected') {

                    var user_data = {};

                    console.log('Welcome!  Fetching your information.... ');
                    FB.api('/me', function (response) {
                        console.log(response)
                        console.log('Good to see you, ' + response.name + '.' + ' Email: ' + response.email + ' Facebook ID: ' + response.id);
                    });

                    user_data.uid = response.authResponse.userID;
                    user_data.accessToken = response.authResponse.accessToken;
                    $http.post('/register/getData', user_data).then(function (response) {
                        self.user = response.data;
                        console.log(self.user)
                    }, function (response) {
                        self.handleError(response);
                    });

                }
                else {
                    self.fb_button = true;
                    FB.login();
                }
            });

        }
        ///
        function getCodes() {
            $http.get('/register/getData').then(function (response) {
                console.log("response  : " + response);
                self.codes = response.data;
            }, function (response) {
                self.handleError(response);
            })
        }
        getCodes()
        self.user = {}
        function onSignIn(googleUser) {
            var profile = googleUser.getBasicProfile();
            console.log('Name: ' + profile.getName());
            var name = profile.getName().split(" ");
            self.user.first_name = name[0];
            self.user.last_name = name[1];
            self.user.email = profile.getEmail();

        }

        //self.signupGmail = signupGmail;
        // function signupGmail(){
        //    if(self.gData.email){
        //        console.log("values")
        //    }
        //     else{
        //       self.gmailSign=true;
        //          self.user=  angular.copy(self.gData)
        //     }
        //    self.user=  angular.copy(self.gData)

        // }
        // signupGmail()
        window.onSignIn = onSignIn;

        //////////////
        function getProfileData() { // Use the API call wrapper to request the member's basic profile data
            IN.API.Profile("me").fields("id,firstName,lastName,email-address,picture-urls::(original),public-profile-url,location:(name)").result(function (me) {
                var profile = me.values[0];
                var id = profile.id;
                var firstName = profile.firstName;
                var lastName = profile.lastName;
                var emailAddress = profile.emailAddress;
                var pictureUrl = profile.pictureUrls.values[0];
                var profileUrl = profile.publicProfileUrl;
                var country = profile.location.name;
            });
        }

        /////////////
        $scope.myMessage;

        var myInt = setInterval(function () {
            if (document.getElementById('myMessage').value !== '') {
                $scope.myMessage = document.getElementById('myMessage').value;
                console.log($scope.myMessage)
                var user = $scope.myMessage.split("/");
                self.user.first_name = user[0];
                self.user.last_name = user[1];
                $scope.$apply();
                clearInterval(myInt);
            }
        }, 150);
    }


}());     
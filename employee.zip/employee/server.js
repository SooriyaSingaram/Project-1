    var db = require('./db'); 
    var express = require('express');
    var bodyParser = require('body-parser'); // pull information from HTML POST (express4)
    var mongoose = require('mongoose'); // mongoose for mongodb
    var app = express(); // create our app with  express

    app.use(bodyParser.urlencoded({
        limit: '1000mb'
    })); // parse application/x-www-form-urlencoded
    app.use(bodyParser.json({
        limit: '1000mb'
    }));

    var Employee = require('./employee');    

    app.get('/getEmployee', function(req, res) {// intial load the index.html
        Employee.find({
            isActive: true
        }, function(err, employees) {
            if (err){
                res.send(err);
            }else{
                res.json(employees);
            }
                
    
            
        });


    });
app.post('/addEmployee',function(req,res){
    var employee = new Employee(req.body);
  
            employee.save(function(err) {
    
                if (err)
                    res.send(err);
                res.send({
                    message: 'Successfully Done'
                });
            })
})
  
    module.exports = app;
    app.listen(4000)
    // listen (start app with node server.js) ======================================
    console.log("App listening on port 4000");

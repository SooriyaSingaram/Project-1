(function () {

    'use strict';

    angular
        .module('app')
        .controller('registerController', RegisterController);

    RegisterController.$inject = ['dataService', '$http'];

    /**
     * @memberof module:register
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function RegisterController(dataService, $http) {

        var self = this,
            data = {},
            url = "/register";
        self.check = check;


        self.addRegister = addRegister;

        // Handles the error while getting false function
        function errorHandler(e) {
            console.log(e.toString());
        }
        /**
         * Add the registers details using data service passing the URL.
         * Its first validate the registers details and allow to add data.
         * On success call getting all registers details in a summary list.
         * @param customerType
         */
        function addRegister(register) {
            dataService.saveData(url, register).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
            function successHandler(responseData) {
                alert(responseData.message);
            }

        }

        ///////Facebook login ///////////        
        function check() {
            FB.getLoginStatus(function (response) {
                if (response.status === 'connected') {

                    var user_data = {};

                    console.log('Welcome!  Fetching your information.... ');
                    FB.api('/me', function (response) {
                        console.log(response)
                        console.log('Good to see you, ' + response.name + '.' + ' Email: ' + response.email + ' Facebook ID: ' + response.id);
                    });

                    user_data.uid = response.authResponse.userID;
                    user_data.accessToken = response.authResponse.accessToken;
                    $http.post('/register/getData', user_data).then(function (response) {
                        self.user = response.data;
                        console.log(self.user)
                    }, function (response) {
                        self.handleError(response);
                    });

                }
                else {
                    self.fb_button = true;
                    FB.login();
                }
            });

        }
        ///
        function getCodes() {
            $http.get('/register/getData').then(function (response) {
                console.log("response  : " + response);
                self.codes = response.data;
            }, function (response) {
                vm.handleError(response);
            })
        }
        getCodes()
    }

}());     
/**
 * login-controller
 */
(function() {
  'use strict';
  angular
    .module('app')
    .controller('loginController', LoginController)
  LoginController.$inject = ['$state', '$rootScope', 'authService',  '$location'];
  /**
     * CRUD application is performed and also displays the data
     * in this login function placed by using authservice
     * @requires $state
     * @requires $rootScope
     * @requires authService
     * @requires ksAlertService
     * @requires $location
     * @ngInject 
     */
  function LoginController($state, $rootScope, authService,  $location) {
    /**
     * Initialize the all function,its load the entire page
     */
    var self = this;
    self.login = login;
    self.userToken = null;
    /**
     * logout function which work by injecting authservice.login()
     */
    function login() {
      authService.login(self.userName, self.password)
        .then(function(result) {
          self.userToken = result;
          $state.go('conference');
        }, function(error) {
          alert("Invalid credentials");
        });
    };
 

  }

}());











(function () {

    'use strict';

    angular
        .module('app')
        .controller('conferenceController', ConferenceController);

    ConferenceController.$inject = ['dataService', '$scope','$http','Upload','$timeout'];

    /**
     * @memberof module:register
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function ConferenceController(dataService, $scope,$http,Upload,$timeout) {

        var vm = this;
       // var url = '/api/v1/conferences/create';
      //  vm.addConference=addConference;
    vm.handleError = function(response) {
        console.log(response.status + " - " + response.statusText + " - " + response.data);
    }
    /////////////////
    //add conference ////////
//      function addConference(a){
       
//   var  reqData = {"channel_id":"doodleblue3",
//                        "title":"zs"   } ;
//                        dataService.saveData(url, reqData).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
//             function successHandler(responseData) {
//                 alert(responseData.message);
//             } 
         
                    
//     }

 function errorHandler(e) {
            console.log(e.toString());
        }
//      function getAllConferences() {
//         $http.get('/api/v1/conferences/get').then(function(response){
//             vm.confData = response.data;
// console.log( vm.confData)      

// }, function(response){
//             vm.handleError(response);
//         });
//   }
//     getAllConferences();
    //addConf()

    vm.del = del;
    function del(a){
        console.log(a)
     $http.post('/api/v1/conferences/delete/', {'data':a}).then(function(response){
           console.log(response.data)
        }, function(response){
            vm.handleError(response);
        });
    }
  vm.getById = getById;
    function getById(a){
        console.log(a)
     $http.post('/conferenceGet', {'data':a}).then(function(response){
          vm.confById = response.data
        }, function(response){
            vm.handleError(response);
        });
    }
    vm.updateConf = updateConf;
    function updateConf(a){
$http.post('/conferenceUpdate', a).then(function(response){
          vm.confById = response.data
        }, function(response){
            vm.handleError(response);
        });
    }
   
$scope.$watch('gFiles', function() {
      $scope.upload($scope.gFiles);
    });
    $scope.upload = function(gFiles) {
      if (gFiles && gFiles.length) {
        for (var i = 0; i < gFiles.length; i++) {
          var file = gFiles[i];
          if (!file.$error) {
          console.log(file)
            Upload.upload({
                url: '/filesdata',
                data: {
                  file: file
                }
              })
              .then(function(response) {
                $timeout(function() {});
              }, function(response) {
                console.log('Error status: ' + response.status);
              }, function(evt) {
                var progressPercentage = parseInt(100.0 *
                  evt.loaded / evt.total);
                $scope.progress = progressPercentage + '% ';
              });
          }
        }
      }
    }

    }

}());     

  
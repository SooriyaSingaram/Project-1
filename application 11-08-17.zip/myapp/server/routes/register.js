var User = require('../models/register'),
    express = require('express'),
    router = express.Router(),
    bcrypt = require('bcryptjs'),
    request = require('request'),
    http = require("https"),
    _ = require('lodash');


router.get('/', function (req, res) {
    res.render('register');
});

//configure routes
router.route('/')
    .get(getUser)
    .post(addUser);
router.route('/getData')
    .post(fetchFbUser)
    .get(getCodes);
router.route('/:id')
    .put(updateUser)
    .get(getUserById)
    .delete(deleteUser);

//Get the All the user Details  
function getUser(req, res) {
    User.find({}, function (err, users) {
        if (err)
            res.send(err);

        res.json(users);
    });
}

///fetch FB user data
function fetchFbUser(req, res) {
    request(' https://graph.facebook.com/v2.6/' + req.body.uid + '?fields=first_name,last_name,email,gender&access_token=' + req.body.accessToken, function (error, response, body) {
        //console.log(body)

        var signupDetail = JSON.parse(body);

        res.json(signupDetail);

    });
}
//Create the New user
function addUser(req, res) {

    var userParam = req.body;
    var userdata = _.omit(userParam, 'password');
    userdata.created_date = new Date();
    userdata.payment = false;
    userdata.hash = bcrypt.hashSync(userParam.password, 10);
    var user = new User(userdata);
    User.count({}, function (err, count) {
        user.save(function (err) {
            if (err)
                res.send(err);
            res.send({
                message: 'Successfully Added'
            });
        });
    })

}


//Update the user Details for Particular Id
function updateUser(req, res) {
    User.findOne({
        _id: req.params.id
    },
        function (err, users) {
            if (err)
                res.send(err);

            for (prop in req.body) {
                users[prop] = req.body[prop];
            }

            // save users details
            users.save(function (err) {
                if (err)
                    res.send(err);

                res.json({
                    message: 'Successfully Updated!'
                });
            });

        });
}
//Get the user Details for Particular Id
function getUserById(req, res) {
    User.findOne({
        _id: req.params.id
    },
        function (err, users) {
            if (err)
                res.send(err);
            res.json(users);
        });
}
//Delete the Particular user
function deleteUser(req, res) {

    User.remove({
        _id: req.params.id
    }, function (err, users) {
        if (err)
            res.send(err);
        res.json({
            message: 'Successfully Deleted'
        });
    });

}

function getCodes(req, resp) {

    var options = {
        "method": "GET",
        "hostname": "gist.githubusercontent.com",
        "port": null,
        "path": "/Goles/3196253/raw/9ca4e7e62ea5ad935bb3580dc0a07d9df033b451/CountryCodes.json",
        "headers": {
            "cache-control": "no-cache",
            "postman-token": "fdc3460c-6e70-35c6-1751-35ec4f4e3fbf"
        }
    };

    var req = http.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);
        });

        res.on("end", function () {
            var body = Buffer.concat(chunks);
            // console.log(body.toString());
            resp.send(body)
        });
    });

    req.end();
}

module.exports = router;
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var conferenceSchema = new Schema({
    id: {
        type: String
    },
    conference_address: {
        type: String
    },
    presenters: [
        {
            presenter_id: String,
            member_id: String,
            conference_id: String,
            first_name: String,
            email: String,
            presenter_url: String,
            title: String,
            bio: String,
            can_manage: Boolean,
            is_moderator: Boolean

        }
    ],
    dial_in_information: {
        dial_in_number: String,
        dial_in_id: String,
        dial_in_passcode: String
    },

    channel_id: {
        type: String
    },
    title: {
        type: String
    },
    schedule_type: {
        type: String
    },
    start_time: {
        type: String
    },
    sub_url: {
        type: String
    },
    exit_url: {
        type: String
    },
    time_zone: {
        type: String
    },
    purpose: {
        type: String
    },
    channel_admin_id: {
        type: String
    },
    room_logo: {
        type: String
    },
    room_sub_title: {
        type: String
    },
    duration: {
        type: Number
    },
    conference_copy_id: {
        type: String
    },
    enable_dial_in: {
        type: Boolean
    }, privacy: {
        type: String
    }, send_reminder_emails_to_presenters: {
        type: Boolean
    },
    send_reminder_emails_to_presenters: {
        type: Boolean
    },
    registration_conf_emails: {
        type: Boolean
    },
    send_cancellation_email: {
        type: Boolean
    },
    show_reviews: {
        type: Boolean
    },
    review_emails: {
        type: Boolean
    },
    poll_results: {
        type: Boolean
    },
    enable_ie_safari: {
        type: Boolean
    },
    enable_twitter: {
        type: Boolean
    },
    auto_invite_all_channel_members: {
        type: Boolean
    },
    background_image_url: {
        type: String
    },
    webhook_url: {
        type: String
    },
    image_url: {
        type: String
    },
    category: {
        type: String
    },
    rating: {
        type: Number
    },
    favourite: {
        type: Boolean
    }


});

conferenceSchema.index({ "$**": "text" });
module.exports = mongoose.model('conference', conferenceSchema);
module.exports.schema = conferenceSchema;

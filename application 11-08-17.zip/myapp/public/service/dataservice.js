/**
 * Data Service
 */

(function () {
    'use strict';
    angular.module('app.data', [])
        .service('dataService', DataService);

    DataService.$inject = ['$http', '$q','authService'];

    /**
     *  service for handling alerts. 
     *
     * @memberof module:app.data
     *
     * @requires $http
     * @requires $q
     * @ngInject
     */

    function DataService($http, $q,authService) {

        var self = this;

        self.getData = getData;
        self.saveData = saveData;
        self.updateData = updateData;
        self.getDataById = getDataById;
        self.deleteData = deleteData;
var loginDat = authService.getUserInfo()._id
        //Getting Data Values in GET API
        function getData(url) {

            var deferred = $q.defer(),
                options = {
                    method: 'GET',
                    cache: false,
                    url: url,
                    headers: {
                        token: authService.getToken(),
                        userid:authService.getUserInfo()._id
                    }
                };

            function handleSuccess(data, status, headers, config) {
                deferred.resolve(data, status, headers, config);
            }

            function handleError(data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            }
            $http(options).success(handleSuccess).error(handleError);
            return deferred.promise;
        }
        //Posting Data Values in POST API
        function saveData(url, data) {


            var deferred = $q.defer(),
                options = {
                    method: 'POST',
                    cache: false,
                    url: url,
                    data: data,
                    headers: {
                        token: authService.getToken(),
                        userInfo:authService.getUserInfo()
                    }
                };

            function handleSuccess(data, status, headers, config) {
                deferred.resolve(data, status, headers, config);
            }

            function handleError(data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            }
            $http(options).success(handleSuccess).error(handleError);
            return deferred.promise;
        }
        //Getting Data Values in GET API based on data ID
        function getDataById(url, id) {

            var deferred = $q.defer(),
                options = {
                    method: 'GET',
                    cache: false,
                    url: url + '/' + id,
                    headers: {
                        token: authService.getToken(),
                        userInfo:authService.getUserInfo()
                    }
                };

            function handleSuccess(data, status, headers, config) {
                deferred.resolve(data, status, headers, config);
            }

            function handleError(data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            }
            $http(options).success(handleSuccess).error(handleError);
            return deferred.promise;
        }
        // Get Data Values based on Id
        function deleteData(url, id) {

            var deferred = $q.defer(),
                options = {
                    method: 'delete',
                    cache: false,
                    url: url + '/' + id,
                    headers: {
                        token: authService.getToken(),
                        userInfo:authService.getUserInfo()
                    }

                };

            function handleSuccess(data, status, headers, config) {
                deferred.resolve(data, status, headers, config);
            }

            function handleError(data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            }
            $http(options).success(handleSuccess).error(handleError);
            return deferred.promise;
        }
        //Updating Data Values in PUT API
        function updateData(url, id, data) {
            var deferred = $q.defer(),
                options = {
                    method: 'PUT',
                    cache: false,
                    url: url + '/' + id,
                    data: data,
                    headers: {
                        token: authService.getToken(),
                        userInfo:authService.getUserInfo()
                    }
                };

            function handleSuccess(data, status, headers, config) {
                deferred.resolve(data, status, headers, config);
            }

            function handleError(data, status, headers, config) {
                deferred.reject(data, status, headers, config);
            }
            $http(options).success(handleSuccess).error(handleError);
            return deferred.promise;
        }
    }
}());
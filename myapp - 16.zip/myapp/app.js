var express = require('express');
var path = require('path'),
  multipart = require('connect-multiparty'),
  fs = require('fs'),
  request = require('request');
require('dotenv').config();

var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var db = require('./server/database'); // connect to mongoDB database in local
var mongoose = require('mongoose'); // mongoose for mongodb


var register = require('./server/models/register');
require('./server/config');
var jwt = require('jwt-simple'); // login auth with session 

var loginCtrl = require('./server/login-controller/auth');// controller for login
var sendEmail = require('./server/mail');// controller for login
var app = express();
// app.set('access_token', '123456ABCDEF');

// view engine setup
//  app.use(express.static(__dirname + '/public'));
app.set('views', path.join(__dirname, '/public'));
// app.set('view engine', 'ejs');


app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var jsonParser = bodyParser.json({ limit: 1024 * 1024 * 20, type: 'application/json' });
var urlencodedParser = bodyParser.urlencoded({ extended: true, limit: 1024 * 1024 * 20, type: 'application/x-www-form-urlencoding' });

app.use(jsonParser);
app.use(urlencodedParser);


app.use(multipart());

app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// app.use('/api', expressJwt({ "access_token": config.secret }).unless({ path: ['/api/login', '/register'] }));



app.use('/register', require('./server/routes/register'));
// app.use('/api/v1/conferences', require('./server/routes/conference'));
app.use('/api/v1/conferences', authentication, require('./server/routes/conference'));
app.post('/api/login', loginCtrl.login); // for login the data
app.post('/api/sendmail', sendEmail.mailFunc); 
 

app.post('/captureRazorpay', function (req, res) {
  request({
    method: 'POST',
    url: 'https://rzp_test_8WnDNfUaenlut1:OFKtzOFnt8KQA6btRKks7rLw@api.razorpay.com/v1/payments/' + req.body.razorpay_payment_id + '/capture',
    //url: 'https://rzp_live_vT9rwHOV629qAP:j8cibmgXJJHUlzaRnWTcrl38@api.razorpay.com/v1/payments/'+req.body.razorpay_payment_id+'/capture',
    form: {
      amount: 100
    }
  }, function (error, response, body) {
    try {
      if (error) {
        res.status(response.statusCode).json({
          "message": error
        });
        return
      }
      else {
        console.log(req.headers.userid);
        var user_id = req.headers.userid;
        register.findOne({
          _id: user_id
        },
          function (err, userDetail) {
            var data = userDetail;
            if (err) {
              res.status(401).json({ "message": "Unauthorized Error" });
              return
            }
            else {
              data.initialPay = 1;
              data.save(function (err) {
                if (err) {
                  res.status(500).send({
                    message: 'Error occured'
                  });
                  return;

                } else {
                  res.status(200).json("messege : Successfully Added")
                }
              });


            }
          })

      }
    } catch (error) {
      console.log(error)
      res.status(503).json({
        "message": 'Internal Server Error'
      });
    }
    // console.log('Status:', response.statusCode);
    // console.log('Response:', body);
  });

})
app.post('/filesdata', function (req, res) {
  var fileDetail = req.files.file;
  var oldpath = fileDetail.path;
  var todayDate = new Date();
  var milliseconds = todayDate.getMilliseconds();
  var newpath = './uploads/' + fileDetail.name + milliseconds;


  fs.rename(oldpath, newpath, function (err) {
    if (err)
      return;
    res.write('File uploaded and moved!');
    res.end(fileDetail.name);
  });
  //
})



// catch 404 and forward to error handler
app.use(function (req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});



function authentication(req, res, next) {
  try {
    var token = req.body.token || req.query.token || req.headers['x-access-token'] || req.headers.token;
    var user_id = req.body.userid || req.query.userid || req.headers['x-access-userid'] || req.headers.userid;
    if (token) {
      if (user_id) {
        register.findOne({
          _id: user_id
        },
          function (err, conferences) {
            var data = conferences;
            if (err) {
              res.status(401).json({ "message": "Unauthorized Error" });
              return
            }
            else {
              var today = new Date()
              var trialDate = new Date(conferences.created_date);
              trialDate.setDate(trialDate.getDate() + 30);
              if (today < trialDate) {
                next();
              }
              else {

                if (conferences.payment == false) {
                  res.status(401).json({
                    status: 'Payment', message: 'Not Paid'
                  });

                }
                else {
                  var paymentDate = new Date(conferences.paid_date);
                  paymentDate.setDate(trialDate.getDate() + 30);
                  if (paymentDate < today) {

                    res.status(401).json({
                      status: 'Payment', message: 'Not Paid'
                    });
                  }
                  else {
                    next()
                  }
                }
              }
            }

          });

      }
      else {
        res.status(401).json({
          message: 'User Not Found'
        });
      }

    }
    else {

      res.sendfile("index.html");

      res.status(401).json({
        "message": "Unauthorized Error"
      });
    }
  }
  catch (e) {
    res.status(404).json({
      "message": "Internal Server Error"
    });
  }



}

module.exports = app;




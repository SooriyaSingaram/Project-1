var nodemailer = require('nodemailer');

module.exports.trans = function(mailTo,sub,text,cb) {
        var transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'surya@askpundit.com',
                pass: 'pass'
            }
        });

        var mailOptions = {

            from: 'noreply@doodleblue.com',
            to: mailTo,
            subject: sub,
            text: text
        };

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                return cb(error)
            } else {
                return cb(undefined,{
                    statusCode: 200,
                    content: 'Email sent'
                })
            }
        });

    }
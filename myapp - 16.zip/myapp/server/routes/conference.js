var Conference = require('../models/conference'),
    performAction = require('../services/commonservice'),
    express = require('express'),
    router = express.Router();

//configure routes
router.route('/create').post(addConference);

router.route('/getAllConference').get(getConference);

router.route('/search').post(searchElastic);

router.route('/:id').put(addToFavourite).get(getConferenceById);

router.route('/update/:id').put(updateConference);

router.route('/delete/:id').delete(deleteConference);

//Get the All the conference Details  
function getConference(req, res) {
    Conference.find({}, function (err, conferences) {
        if (err) {
            resp.status(401).send({
                message: 'Unauthorized Error'
            });
            return
        } else {
            res.json(conferences);
        }

    });
}

//Create the New conference
function addConference(reqs, resp) {
    var payload = JSON.stringify(reqs.body);
    performAction.getResults(reqs, 'POST', payload, function (err, results) {
        if (err) {
            resp.status(400).send({
                message: 'Please Fill the required fields (channel_id , title)'
            });
            return;
        } else {
            // console.log(results)
            if (results.statusCode == 201) {
                var dataParse = JSON.parse(results.content)
                var conferences = new Conference(dataParse);
                Conference.count({}, function (err, count) {
                    conferences.save(function (err) {
                        if (err) {
                            resp.send(err);
                            return
                        } else {
                            resp.send({
                                message: 'Successfully Added'
                            });
                        }

                    });
                })
            } else {
                resp.status(503).send({
                    message: 'Error occured'
                });
            }
        }
    });

}

//Add to Fav the Conference Details for Particular Id
function addToFavourite(req, res) {
    Conference.findOne({
        _id: req.params.id
    },
        function (err, conferences) {
            if (err) {
                res.send(err);
                return
            } else {
                for (prop in req.body) {
                    conferences[prop] = req.body[prop];
                }
                conferences.save(function (err) {
                    if (err) {
                        res.send(err);
                    } else {
                        res.json({
                            message: 'Successfully Added to favourite list!'
                        });
                    }

                });
            }
        });
}

//update conference for particular id
function updateConference(reqs, resp) {
    reqs.body.start_time = startDateFormat(reqs)
    var payload = JSON.stringify(reqs.body);
    performAction.getResults(reqs, 'PUT', payload, function (err, results) {
        if (err) {
            console.error(err);
            return;
        }
        if (results.statusCode == 200) {
            var dataParse = JSON.parse(results.content)
            var confData = new Conference(dataParse);
            Conference.findOne({
                'id': reqs.params.id
            },
                function (err, conferences) {
                    if (err) {
                        resp.status(500).send({
                            message: 'Error occured'
                        });
                        return
                    }
                    for (prop in confData) {
                        conferences[prop] = confData[prop];
                    }
                    // save conferences details
                    conferences.save(function (err) {
                        if (err) {
                            resp.status(500).send({
                                message: 'Error occured'
                            });
                            return
                        } else {
                            resp.status(200).json(conferences);
                        }
                    });

                });
        } else {
            resp.status(503).send({
                message: 'Error occured'
            });
        }

    });

}

//Get the Conference Details for Particular Id
function getConferenceById(req, res) {
    Conference.findOne({
        _id: req.params.id
    },
        function (err, conferences) {
            if (err)
                res.send(err);
            res.json(conferences);
        });
}

//delete conference
function deleteConference(reqs, resp) {

    performAction.getResults(reqs, 'DELETE', undefined, function (err, results) {
        if (err) {
            console.error(err);
            return;
        } else {
            if (results.statusCode == 204) {
                Conference.remove({
                    'id': reqs.params.id
                }, function (err, conferences) {
                    if (err) {
                        resp.send(err);
                        return
                    } else {
                        resp.status(200).send({
                            message: 'Successfully Deleted'
                        });
                    }

                });
            } else {
                resp.status(503).send({
                    message: 'Error occured'
                });
            }
        }
    });
}

//Elastic search functionality

function searchElastic(req, res) {
    var searchField = req.body.data;
    Conference.find({
        $text: {
            $search: req.body.data
        }
    }, function (err, conferences) {
        if (err) {
            res.status(404).send({
                message: 'Data Not Found'
            });
            return;
           
        } else {
            res.json(conferences);
        }
    })
}
//change date format to required format
function startDateFormat(requ) {
    var now = new Date(requ.body.start_time);
    var pretty = [
        now.getFullYear(),
        '-',
        (now.getMonth() + 1) < 10 ? ('0' + (now.getMonth() + 1)) : now.getMonth() + 1,
        '-',
        now.getDate() < 10 ? ('0' + now.getDate()) : now.getDate(),
        ' ',
        now.getHours() < 10 ? ('0' + now.getHours()) : now.getHours(),
        ':',
        now.getMinutes() < 10 ? ('0' + now.getMinutes()) : now.getMinutes()
    ].join('');
    return pretty;
}

module.exports = router;
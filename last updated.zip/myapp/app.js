var express = require('express');
var path = require('path'),
  multipart = require('connect-multiparty'),
  fs = require('fs'),
  request = require('request');
require('dotenv').config();
var Mailgun = require('mailgun-js');



var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var db = require('./server/database'); // connect to mongoDB database in local
var mongoose = require('mongoose'); // mongoose for mongodb


var register = require('./server/models/register');
require('./server/config');
var jwt = require('jwt-simple'); // login auth with session 

var loginCtrl = require('./server/login-controller/auth');// controller for login
var sendEmail = require('./server/mail');// controller for login
var app = express();
// app.set('access_token', '123456ABCDEF');

// view engine setup
//  app.use(express.static(__dirname + '/public'));
app.set('views', path.join(__dirname, '/public'));
// app.set('view engine', 'ejs');


app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var jsonParser = bodyParser.json({ limit: 1024 * 1024 * 20, type: 'application/json' });
var urlencodedParser = bodyParser.urlencoded({ extended: true, limit: 1024 * 1024 * 20, type: 'application/x-www-form-urlencoding' });

app.use(jsonParser);
app.use(urlencodedParser);


app.use(multipart());

app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// app.use('/api', expressJwt({ "access_token": config.secret }).unless({ path: ['/api/login', '/register'] }));

app.use('/register', require('./server/routes/register'));
// app.use('/api/v1/conferences', require('./server/routes/conference'));
app.use('/api/v1/conferences', authentication, require('./server/routes/conference'));
app.post('/api/login', loginCtrl.login); // for login the data
app.post('/api/sendmail', function(req,res){
//Your api key, from Mailgun’s Control Panel
var api_key = 'key-e6544d8188677889667c14b193b6bb3a';

//Your domain, from the Mailgun Control Panel
var domain = 'sandboxcd2dbac5d955460385d3654eda7c532c.mailgun.org';

//Your sending email address
var from_who = 'surya.doodleblue@gmail.com';

var mailgun = new Mailgun({apiKey: api_key, domain: domain});

    var data = {
    //Specify email data
      from: from_who,
    //The email to contact
      to: req.body.data,
    //Subject and text data  
      subject: 'Hello from Mailgun',
      html: 'Hello, This is not a plain-text email'
    }

    //Invokes the method to send emails given the above data with the helper library
    mailgun.messages().send(data, function (err, body) {
        //If there is an error, render the error page
        if (err) {
            res.render('error', { error : err});
            console.log("got an error: ", err);
        }
        //Else we can greet    and leave
        else {
            //Here "submitted.jade" is the view file for this landing page 
            //We pass the variable "email" from the url parameter in an object rendered by Jade
            res.render('submitted', { email : req.body.data });
            console.log(body);
             }
    });




}); 
 

app.post('/captureRazorpay', function (req, res) {
  request({
    method: 'POST',
    url: 'https://rzp_test_8WnDNfUaenlut1:OFKtzOFnt8KQA6btRKks7rLw@api.razorpay.com/v1/payments/' + req.body.razorpay_payment_id + '/capture',
    //url: 'https://rzp_live_vT9rwHOV629qAP:j8cibmgXJJHUlzaRnWTcrl38@api.razorpay.com/v1/payments/'+req.body.razorpay_payment_id+'/capture',
    form: {
      amount: 100
    }
  }, function (error, response, body) {
    try {
      if (error) {
        res.status(response.statusCode).json({
          "message": error
        });
        return
      }
      else {
        console.log(req.headers.userid);
        var user_id = req.headers.userid;
        register.findOne({
          _id: user_id
        },
          function (err, userDetail) {
            var data = userDetail;
            if (err) {
              res.status(401).json({ "message": "Unauthorized Error" });
              return
            }
            else {
              data.initialPay = 1;
              data.save(function (err) {
                if (err) {
                  res.status(500).send({
                    message: 'Error occured'
                  });
                  return;

                } else {
                  res.status(200).json("messege : Successfully Added")
                }
              });


            }
          })

      }
    } catch (error) {
      console.log(error)
      res.status(503).json({
        "message": 'Internal Server Error'
      });
    }
    // console.log('Status:', response.statusCode);
    // console.log('Response:', body);
  });

})
app.post('/filesdata', function (req, res) {
  var fileDetail = req.files.file;
  var oldpath = fileDetail.path;
  var todayDate = new Date();
  var milliseconds = todayDate.getMilliseconds();
  var newpath = './uploads/' + fileDetail.name + milliseconds;


  fs.rename(oldpath, newpath, function (err) {
    if (err)
      return;
    res.write('File uploaded and moved!');
    res.end(fileDetail.name);
  });
  //
})



// catch 404 and forward to error handler
app.use(function (req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});



function authentication(req, res, next) {
  try {
    var token = req.body.token || req.query.token || req.headers['x-access-token'] || req.headers.token;
    var user_id = req.body.userid || req.query.userid || req.headers['x-access-userid'] || req.headers.userid;
    if (token) {
      if (user_id) {
        register.findOne({
          _id: user_id
        },
          function (err, conferences) {
            var data = conferences;
            if (err) {
              res.status(401).json({ "message": "Unauthorized Error" });
              return
            }
            else {
              try {
                 var today = new Date()
              var trialDate = new Date(conferences.created_date);
              trialDate.setDate(trialDate.getDate() + 30);
              if (today < trialDate) {
                next();
              }
              else {

                if (conferences.payment == false) {
                  res.status(401).json({
                    status: 'Payment', message: 'Not Paid'
                  });

                }
                else {
                  var paymentDate = new Date(conferences.paid_date);
                  paymentDate.setDate(trialDate.getDate() + 30);
                  if (paymentDate < today) {

                    res.status(401).json({
                      status: 'Payment', message: 'Not Paid'
                    });
                  }
                  else {
                    next()
                  }
                }
              }
              } catch (error) {
                console.log(error)
                res.status(500).json({
                  message:"Server not responding"
                })
              }
             
            }

          });

      }
      else {
        res.status(401).json({
          message: 'User Not Found'
        });
      }

    }
    else {

      res.sendfile("index.html");

      res.status(401).json({
        "message": "Unauthorized Error"
      });
    }
  }
  catch (e) {
    res.status(404).json({
      "message": "Internal Server Error"
    });
  }



}

//////////////////////////////////////////////////////////////////////////////////////
var elastic = require('./server/elasticsearch');
var Conference = require('./server/models/conference');

elastic.indexExists().then(function (exists) {  
  if (exists) {
    return elastic.deleteIndex();
  }
}).then(function () {
  return elastic.initIndex().then(elastic.initMapping).then(function () {
    var promises;
    //Add a few titles for the autocomplete
    //elasticsearch offers a bulk functionality as well, but this is for a different time
Conference.find({}, function (err, conferences) {
  
        if (err) {
            resp.status(401).send({
                message: 'Unauthorized Error'
            });
            return
        } else {
           promises = conferences;
        }

    }).then(function(promises){
     promises.map(function (conferenceDetail) {
       return elastic.addDocument({
        title: conferenceDetail.title,
         content: conferenceDetail.channel_id,
         speaker:conferenceDetail.presenters[0].first_name,
         metadata: {
           titleLength: conferenceDetail.length
         }
       });
    });
    return Promise.all(promises);
    })
  });
});

module.exports = app;


////8c1708b7ecf542da8161

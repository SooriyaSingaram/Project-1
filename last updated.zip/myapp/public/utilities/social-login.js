  window.fbAsyncInit = function() {
    FB.init({
      appId            : '312447839230283',
      autoLogAppEvents : true,
      xfbml            : true,
      version          : 'v2.10'
    });
    FB.AppEvents.logPageView();
  };

var finished_rendering = function() {
console.log("finished rendering plugins");

}
FB.Event.subscribe('xfbml.render', finished_rendering);
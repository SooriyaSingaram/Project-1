(function () {

    'use strict';

    angular
        .module('app')
        .controller('razorpayController', razorpayController);

    razorpayController.$inject = ['$scope', 'dataService', '$state'];

    /**
     * @memberof module:register
     *
     * Payment integration
     * @requires dataService
     * @ngInject
     */
    function razorpayController($scope, dataService, $state) {

        var vm = this;

        $scope.options = {
            'method': {
                'wallet': false,
                'upi': false,
                'netbanking': false
            },
            "key": "rzp_test_8WnDNfUaenlut1",
            // for test  'key': 'rzp_live_vT9rwHOV629qAP',
            'amount': 100,
            'name': '',
            'description': 'Pay for Order #2323',
            'image': '',
            'handler': function (transaction) {
                $scope.transactionHandler(transaction);
                // /alert(transaction.razorpay_payment_id);
            },
            'prefill': {
                'name': '',
                'email': '',
                'contact': ''
            },
            theme: {
                color: '#3399FF'
            }
        };

        $scope.pay = function () {
            $.getScript('https://checkout.razorpay.com/v1/checkout.js', function () {
                var rzp1 = new Razorpay($scope.options);
                rzp1.open();

            });

            $scope.transactionHandler = function (transaction) {
                console.log(transaction);
                dataService.saveData('/captureRazorpay', transaction).then(function (response) {
                    // $http.post('https://api.razorpay.com/v1/payments/'+ transaction.razorpay_payment_id+'/capture', {'amount':100}).then(function(response){
                    console.log(response)
                    if (response.message = "Captured") {
                        $state.go('login')
                    }
                })
            }
        };




    }

}());


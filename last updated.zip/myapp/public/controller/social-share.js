(function () {

    'use strict';

    angular
        .module('app')
        .controller('testController', testController);

    testController.$inject = ['dataService', '$http', '$state', '$scope'];

    /**
     * @memberof module:register
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function testController($scope, $timeout, Socialshare) {

        var self = this;
       self.url = "http://720kb.net";
       self.testValue = "This video from Medvarsity ... "
    }


}());     
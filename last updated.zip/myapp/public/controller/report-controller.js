(function () {

    'use strict';

    angular
        .module('app')
        .controller('reportController', reportController);

    reportController.$inject = ['dataService'];

    /**
     * @memberof module:app
     *
     * report based on conference attendance
     * @requires dataService
     * @ngInject
     */
    function reportController(dataService) {

        var self = this;
        self.attendeesDetail = [];
        console.log("report controller");
        function getAllReport() {
            dataService.getData('/api/v1/conferences/getAllReport').then(function (response) {
                self.report = response.attendees;
                console.log(self.report);
                mappedUsers()

            }, function (response) {
                console.log(response)
            });
        }


        function getAllUser() {
            dataService.getData('/register').then(function (response) {
                self.allUsers = response;
                
            }, function (response) {
                console.log(response)
            });
        }

        function mappedUsers() {
            
                angular.forEach(self.allUsers, function (rep) {
                    angular.forEach(self.report, function (det) {
                        if (rep.email == det.email) {
                            console.log(rep);
                            self.attendeesDetail.push(rep)
                        }
                    })
                })
            

        }
            
        function init() {
            getAllUser();
            getAllReport();

        }
        init()
    }


}());     
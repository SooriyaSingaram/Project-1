/**
 * login-controller
 */
(function() {
  'use strict';
  angular
    .module('app')
    .controller('loginController', LoginController)

.run(function ($rootScope, $state, authService) {
 $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
   if (authService.getToken() == undefined  ) {
    if(toState.name == 'register'){
      $state.go('register')
    }
    else{
      $state.go('login')
    }
  }
        });


});

  LoginController.$inject = ['$state', '$scope','$rootScope', 'authService',  '$location','$http'];
  /**
     * CRUD application is performed and also displays the data
     * in this login function placed by using authservice
     * @requires $state
     * @requires $rootScope
     * @requires authService
     * @requires ksAlertService
     * @requires $location
     * @ngInject 
     */
  function LoginController($state,$scope, $rootScope, authService,  $location,$http) {
    /**
     * Initialize the all function,its load the entire page
     */
    var self = this;
    self.login = login;
    self.userToken = null;
    self.check=check;
    /**
     * logout function which work by injecting authservice.login()
     */
    function login(a) {
           authService.login(a.email, a.password)
        .then(function(result) {
          console.log(result);
          self.userToken = result;
          $state.go('conference');
        }, function(error) {
          alert("Invalid credentials");
        });
    };
 
      ///////Facebook login ///////////        
        function check() {
            FB.getLoginStatus(function (response) {
                if (response.status === 'connected') {

                    var user_data = {};

                    console.log('Welcome!  Fetching your information.... ');
                    FB.api('/me', function (response) {
                        console.log(response)
                        console.log('Good to see you, ' + response.name + '.' + ' Email: ' + response.email + ' Facebook ID: ' + response.id);
                    });

                    user_data.uid = response.authResponse.userID;
                    user_data.accessToken = response.authResponse.accessToken;
                    $http.post('/register/getData', user_data).then(function (response) {
                        self.user = response.data;
                        console.log(self.user);
                        if(self.user.emai){
                          var data = {};
                          data.email = self.user.emai;
                          data.password = 'social'
                          login(data)
                        }
                        else{
                          alert('plz provide valid email id and password')
                        }
                    }, function (response) {
                        self.handleError(response);
                    });

                }
                else {
                    self.fb_button = true;
                    FB.login();
                }
            });

        }
          ////////////////linked in 
              function getProfileData() { // Use the API call wrapper to request the member's basic profile data
            IN.API.Profile("me").fields("id,firstName,lastName,email-address,picture-urls::(original),public-profile-url,location:(name)").result(function (me) {
                var profile = me.values[0];
                var id = profile.id;
                var firstName = profile.firstName;
                var lastName = profile.lastName;
                var emailAddress = profile.emailAddress;
                var pictureUrl = profile.pictureUrls.values[0];
                var profileUrl = profile.publicProfileUrl;
                var country = profile.location.name;
            });
        }

        /////////////
        $scope.myMessage;

        // var myInt = setInterval(function () {
        //     if (document.getElementById('myMessage').value !== '') {
        //         $scope.myMessage = document.getElementById('myMessage').value;
        //         console.log($scope.myMessage)
        //         var user = $scope.myMessage.split("/");
        //         self.user.first_name = user[0];
        //         self.user.last_name = user[1];
        //         $scope.$apply();
        //         clearInterval(myInt);
        //     }
        // }, 150);
  }


}());













(function () {

    'use strict';

    angular
        .module('app')
        .controller('conferenceController', ConferenceController);

    ConferenceController.$inject = ['dataService', '$scope', 'Upload', '$timeout', 'authService','$location'];

    /**
     * @memberof module:register
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function ConferenceController(dataService, $scope, Upload, $timeout, authService,$location) {

        var vm = this;
        vm.addConf = addConf;
        vm.addToFav = addToFav;
        vm.logoutUser = logoutUser;
        vm.search =search;
        function search(a){
           dataService.saveData('/api/v1/conferences/search', {data:a}).then(function (response) {
                console.log(response.data)
            }, function (response) {
                vm.handleError(response);
            });
        }

        function logoutUser() {
            authService.logout();
            $location.path('/')
        }
        vm.handleError = function (response) {
            console.log(response.status + " - " + response.statusText + " - " + response.data);
        }
        /////////////////
        function addConf() {
            var reqData = {
                "channel_id": "doodleblue3",
                "title": "title name def"
            };
            dataService.saveData('/api/v1/conferences', reqData).then(function (response) {
                console.log(response.data)
            }, function (response) {
                vm.handleError(response);
            });
        }
        // addConf()
        function addToFav(a) {
            a.favourite = true;
            dataService.updateData('/api/v1/conferences', a._id, a).then(function (response) {
                console.log(response)
            }, function (response) {
                vm.handleError(response);
            });


        }
        function errorHandler(e) {
            console.log(e.toString());
        }
        function getAllConferences() {
            dataService.getData('/api/v1/conferences/getAllConference').then(function (response) {
                vm.confData = response;
                console.log(vm.confData)

            }, function (response) {
                vm.handleError(response);
            });
        }
        getAllConferences();

        vm.del = del;
        function del(a) {
            console.log(a)
            dataService.deleteData('/api/v1/conferences', a.id).then(function (response) {
                console.log(response.data)
            }, function (response) {
                vm.handleError(response);
            });
        }
        vm.getById = getById;
        function getById(a) {
            console.log(a)

            dataService.getDataById('/api/v1/conferences', a).then(function (response) {
                vm.confById = response
                console.log(vm.confById)
            }, function (response) {
                vm.handleError(response);
            });
        }
        vm.updateConf = updateConf;
        function updateConf(a) {
            console.log(a)
            dataService.updateData('/api/v1/conferences/update', a.id, a).then(function (response) {
                vm.confById = response.data
            }, function (response) {
                vm.handleError(response);
            });
        }

        $scope.$watch('gFiles', function () {
            $scope.upload($scope.gFiles);
        });
        $scope.upload = function (gFiles) {
            if (gFiles && gFiles.length) {
                for (var i = 0; i < gFiles.length; i++) {
                    var file = gFiles[i];
                    if (!file.$error) {
                        console.log(file)
                        Upload.upload({
                            url: '/filesdata',
                            data: {
                                file: file
                            }
                        })
                            .then(function (response) {
                                $timeout(function () { });
                            }, function (response) {
                                console.log('Error status: ' + response.status);
                            }, function (evt) {
                                var progressPercentage = parseInt(100.0 *
                                    evt.loaded / evt.total);
                                $scope.progress = progressPercentage + '% ';
                            });
                    }
                }
            }
        }

        

    }

}());


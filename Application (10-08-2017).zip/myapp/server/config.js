/**
 * Passport Router
 */
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var mongoose = require('mongoose');
var Employee = require('./models/register');
var bcrypt = require('bcryptjs');



passport.use(new LocalStrategy({
    usernameField: 'email',
    passwordField: 'password'
  },
  function(email, password, done) {
    Employee.findOne({ email: email }, function(err, employee) {
      if (err) { return done(err); }
      // Return if employee not found in database
      if (!employee) {
        return done(null, false, {
          message: 'Employee not found'
        });
      }
      else{
if(password){
  if(password !== 'social'){
  var validPassword = bcrypt.compareSync(password, employee.hash)
  console.log(validPassword);
  if (!validPassword) {
        return done(null, false, {
          message: 'Password is wrong'
        });
      }
  }

}

      }
      // Return if password is wrong
      
      // If credentials are correct, return the user object
      return done(null, employee);
    });
  }
));


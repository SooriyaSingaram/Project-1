var mongoose = require('mongoose');
var jwt =require('jwt-simple');

var userSchema =  mongoose.Schema({
    first_name: {
        type: String
    },
   last_name: {
        type: String
    },
    email: {
        type: String
    },
    code: {
        type: String
    },
    mobile:{
        type: Number
    },
    payment:{
        type: Boolean
    },
    hash:{
        type: String
    }

});



userSchema.methods.generateJwt = function() {
  var expiry = new Date();
  expiry.setDate(expiry.getMinutes() + 1);

  return jwt.encode({
    _id: this._id,
    exp: parseInt(expiry.getTime()/1000),
  }, '123456ABCDEF');
};


module.exports = mongoose.model('user', userSchema);
module.exports.schema = userSchema;



var Conference = require('../models/conference'),
    express = require('express'),
    router = express.Router(),
    request = require('request'),
    http = require("https");

//configure routes
router.route('/')
    .post(addConference);

router.route('/getAllConference')
    .get(getConference);

router.route('/search')
    .post(searchElastic);

router.route('/:id')
    .put(addToFavourite)
    .get(getConferenceById)
    .delete(deleteConference);
router.route('/update/:id')
    .put(updateConference)

//Get the All the conference Details  
function getConference(req, res) {
    Conference.find({}, function (err, conferences) {
        if (err) {
            res.send(err);
            return
        }
        else {
            res.json(conferences);
        }

    });
}

//Create the New conference
function addConference(reqs, resp) {

    var confData = JSON.stringify(reqs.body);
    var options = {
        "method": "POST",
        "hostname": "www.bigmarker.com",
        "port": null,
        "path": "/api/v1/conferences",
        "headers": {
            "api-key": "8c1708b7ecf542da8161"
        }
    };

    var req = http.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);
        });

        res.on("end", function () {
            var body = Buffer.concat(chunks);
            try {
                var conf = JSON.parse(body.toString());

                if (conf.id) {
                    var conferences = new Conference(conf);
                    Conference.count({}, function (err, count) {
                        conferences.save(function (err) {
                            if (err)
                                resp.send(err);
                            resp.send({
                                message: 'Successfully Added'
                            });
                        });
                    })
                }
                else {
                    resp.status(400).send({ message: 'Please Fill the required fields (channel_id , title)' });
                }
            } catch (error) {
                resp.status(400).send({ message: 'Please Fill the required fields (channel_id , title)' });
            }


        });
    });

    req.write(confData);
    req.end();

}

//Add to Fav the Conference Details for Particular Id
function addToFavourite(req, res) {
    Conference.findOne({
        _id: req.params.id
    },
        function (err, conferences) {
            if (err) {
                res.send(err);
                return
            }
            else {
                for (prop in req.body) {
                    conferences[prop] = req.body[prop];
                }

                // save conferences details
                conferences.save(function (err) {
                    if (err) {
                        res.send(err);
                    }

                    else {
                        res.json({
                            message: 'Successfully Added to favourite list!'
                        });
                    }

                });
            }
        });
}
//Add to Fav the Conference Details for Particular Id
function updateConference(requ, resp) {
    var now = new Date(requ.body.start_time);
    var pretty = [
        now.getFullYear(),
        '-',
        (now.getMonth() + 1) < 10 ? ('0' + (now.getMonth() + 1)) : now.getMonth() + 1,
        '-',
        now.getDate() < 10 ? ('0' + now.getDate()) : now.getDate(),
        ' ',
        now.getHours() < 10 ? ('0' + now.getHours()) : now.getHours(),
        ':',
        now.getMinutes() < 10 ? ('0' + now.getMinutes()) : now.getMinutes()
    ].join('');
    requ.body.start_time = pretty;

    var options = {
        "method": "PUT",
        "hostname": "www.bigmarker.com",
        "port": null,
        "path": "/api/v1/conferences/" + requ.params.id,
        "headers": {
            "api-key": "8c1708b7ecf542da8161"
        }
    };

    var req = http.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);
        });

        res.on("end", function () {
            var body = Buffer.concat(chunks);
            // console.log(body.toString());
            try {
                var conferenceUp = JSON.parse(body.toString());
                if (conferenceUp.id) {
                    Conference.findOne({
                        'id': conferenceUp.id
                    },
                        function (err, conferences) {
                            if (err)
                                res.send(err);

                            for (prop in requ.body) {
                                conferences[prop] = requ.body[prop];
                            }

                            // save conferences details
                            conferences.save(function (err) {
                                if (err) {
                                    resp.send(err);
                                    return
                                }
                                else {
                                    resp.json(conferences);
                                }
                            });

                        });
                }

            } catch (error) {
                console.log(error)
            }

        });
    });
    var d = JSON.stringify(requ.body)
    req.write(d);
    req.end();

}
//Get the Conference Details for Particular Id
function getConferenceById(req, res) {
    console.log(req.params.id)
    Conference.findOne({
        _id: req.params.id
    },
        function (err, conferences) {
            if (err)
                res.send(err);
            res.json(conferences);
        });
}

//Delete the Particular Conference
function deleteConference(reqs, resp) {
    console.log(reqs.params.id)
    var options = {
        "method": "DELETE",
        "hostname": "www.bigmarker.com",
        "port": null,
        "path": "/api/v1/conferences/" + reqs.params.id,
        "headers": {
            "api-key": "8c1708b7ecf542da8161"
        }
    };

    var req = http.request(options, function (res) {
        var chunks = [];

        res.on("data", function (chunk) {
            chunks.push(chunk);
        });

        res.on("end", function () {
            try {
                var body = Buffer.concat(chunks);
                var a = body.toString();
                Conference.remove({
                    'id': reqs.params.id
                }, function (err, conferences) {
                    if (err) {
                        resp.send(err);
                        return
                    }
                    else {
                        resp.json({
                            message: 'Successfully Deleted'
                        });
                    }

                });
            }
            catch (e) {
                resp.status(503).send({ message: 'Please try again' });

            }


        });
    });

    req.end();

}

function searchElastic(req, res) {
    var searchField = req.body.data;
    Conference.find({ $text: { $search: req.body.data } }, function (err, conferences) {
        if (err) {
            res.status(404).send({ message: 'Data Not Found' });
        }
        else {
            res.json(conferences);
        }
    })
}


module.exports = router;

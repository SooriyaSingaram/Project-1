var app = require('../server_api');

var user = require('../services/user/user');
var tracking = require('../services/tracking/tracking');


app.post('/api/v1/deviceTracking',tracking.device_tracking)


app.post('/api/v1/userTracking',tracking.user_tracking)


app.post('/api/v1/activityTracking',tracking.activity_tracking)

var Conference = require('../models/conference'),
    express = require('express'),
    router = express.Router(),
    request = require('request'),
    http = require("https");

//configure routes
router.route('/')
    .post(addConference);

router.route('/getAllConference')
    .get(getConference)


router.route('/:id')
    .put(addToFavourite)
    .get(getConferenceById)
    .delete(deleteConference);
router.route('/update/:id')
    .put(updateConference)

//Get the All the conference Details  
function getConference(req, res) {
    // db.users.find({}).limit(2).skip(0, function(err, docs) { console.log(docs); });
    Conference.find({}, function(err, conferences) {
        if (err)
            res.send(err);

        res.json(conferences);
    }).skip(1).limit(5);
}

//Create the New conference
function addConference(reqs, resp) {

    var confData = JSON.stringify(reqs.body);
    var options = {
        "method": "POST",
        "hostname": "www.bigmarker.com",
        "port": null,
        "path": "/api/v1/conferences",
        "headers": {
            "api-key": "8c1708b7ecf542da8161"
        }
    };

    var req = http.request(options, function(res) {
        var chunks = [];

        res.on("data", function(chunk) {
            chunks.push(chunk);
        });

        res.on("end", function() {
            var body = Buffer.concat(chunks);
            var conf = JSON.parse(body.toString());

            if (conf.id) {
                console.log(conf)
                var conferences = new Conference(conf);
                console.log(conferences)
                Conference.count({}, function(err, count) {
                    conferences.save(function(err) {
                        if (err)
                            res.send(err);
                        resp.send({
                            message: 'Successfully Added'
                        });
                    });
                })
            }
        });
    });
   
    req.write(confData);
    // console.log(confData)
    req.end();

}

//Add to Fav the Conference Details for Particular Id
function addToFavourite(req, res) {
    Conference.findOne({
            _id: req.params.id
        },
        function(err, conferences) {
            if (err)
                res.send(err);

            for (prop in req.body) {
                conferences[prop] = req.body[prop];
            }

            // save conferences details
            conferences.save(function(err) {
                if (err)
                    res.send(err);

                res.json({
                    message: 'Successfully Updated!'
                });
            });

        });
}
//Add to Fav the Conference Details for Particular Id
function updateConference(requ, resp) {
    var now = new Date(requ.body.start_time);
    var pretty = [
        now.getFullYear(),
        '-',
        (now.getMonth() + 1) < 10 ? ('0' + (now.getMonth() + 1)) : now.getMonth() + 1,
        '-',
        now.getDate() < 10 ? ('0' + now.getDate()) : now.getDate(),
        ' ',
        now.getHours() < 10 ? ('0' + now.getHours()) : now.getHours(),
        ':',
        now.getMinutes() < 10 ? ('0' + now.getMinutes()) : now.getMinutes()
    ].join('');
    requ.body.start_time = pretty;

    var options = {
        "method": "PUT",
        "hostname": "www.bigmarker.com",
        "port": null,
        "path": "/api/v1/conferences/" + requ.params.id,
        "headers": {
            "api-key": "8c1708b7ecf542da8161",
            "content-type": "application/json",
            "cache-control": "no-cache",
            "postman-token": "a9b20754-95fa-e441-553b-75d3fc6cad82"
        }
    };

    var req = http.request(options, function(res) {
        var chunks = [];

        res.on("data", function(chunk) {
            chunks.push(chunk);
        });

        res.on("end", function() {
            var body = Buffer.concat(chunks);
           // console.log(body.toString());
            try {
                var conferenceUp = JSON.parse(body.toString());
                if (conferenceUp.id) {
                    Conference.findOne({
                            'id': conferenceUp.id
                        },
                        function(err, conferences) {
                            if (err)
                                res.send(err);

                            for (prop in requ.body) {
                                conferences[prop] = requ.body[prop];
                            }

                            // save conferences details
                            conferences.save(function(err) {
                                if (err)
                                    resp.send(err);

                                resp.json(conferences);
                            });

                        });
                }

            } catch (error) {
                console.log(error)
            }




        });
    });
    var d = JSON.stringify(requ.body)
    //console.log(d)
    req.write(d);
    req.end();



}
//Get the Conference Details for Particular Id
function getConferenceById(req, res) {
    console.log(req.params.id)
    Conference.findOne({
            _id: req.params.id
        },
        function(err, conferences) {
            if (err)
                res.send(err);
            res.json(conferences);
        });
}
//Delete the Particular Conference
function deleteConference(reqs, resp) {
    console.log(reqs.params.id)
    var options = {
        "method": "DELETE",
        "hostname": "www.bigmarker.com",
        "port": null,
        "path": "/api/v1/conferences/" + reqs.params.id,
        "headers": {
            "api-key": "8c1708b7ecf542da8161",
            "cache-control": "no-cache",
            "postman-token": "f938990f-7dfe-fed4-4262-a1c1a38b1d8d"
        }
    };

    var req = http.request(options, function(res) {
        var chunks = [];

        res.on("data", function(chunk) {
            chunks.push(chunk);
        });

        res.on("end", function() {
            var body = Buffer.concat(chunks);
            console.log("deleted")
            var a = body.toString();
            console.log(body.toString());
            Conference.remove({
                'id': reqs.params.id
            }, function(err, conferences) {
                if (err)
                    resp.send(err);
                resp.json({
                    message: 'Successfully Deleted'
                });
            });

        });
    });

    req.end();

}

module.exports = router;
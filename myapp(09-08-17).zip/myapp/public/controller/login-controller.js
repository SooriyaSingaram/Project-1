/**
 * login-controller
 */
(function() {
  'use strict';
  angular
    .module('app')
    .controller('loginController', LoginController)

.run(function ($rootScope, $state, authService) {
 $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
   if (authService.getToken() == undefined  ) {
    if(toState.name == 'register'){
      $state.go('register')
    }
    else{
      $state.go('login')
    }
  }
        });


});

  LoginController.$inject = ['$state', '$rootScope', 'authService',  '$location','$http'];
  /**
     * CRUD application is performed and also displays the data
     * in this login function placed by using authservice
     * @requires $state
     * @requires $rootScope
     * @requires authService
     * @requires ksAlertService
     * @requires $location
     * @ngInject 
     */
  function LoginController($state, $rootScope, authService,  $location,$http) {
    /**
     * Initialize the all function,its load the entire page
     */
    var self = this;
    self.login = login;
    self.userToken = null;
    self.check=check;
    /**
     * logout function which work by injecting authservice.login()
     */
    function login(a) {
      console.log('i am call')
           authService.login(a.email, a.password)
        .then(function(result) {
          console.log(result);
          self.userToken = result;
          $state.go('conference');
        }, function(error) {
          alert("Invalid credentials");
        });
    };
 
      ///////Facebook login ///////////        
        function check() {
            FB.getLoginStatus(function (response) {
                if (response.status === 'connected') {

                    var user_data = {};

                    console.log('Welcome!  Fetching your information.... ');
                    FB.api('/me', function (response) {
                        console.log(response)
                        console.log('Good to see you, ' + response.name + '.' + ' Email: ' + response.email + ' Facebook ID: ' + response.id);
                    });

                    user_data.uid = response.authResponse.userID;
                    user_data.accessToken = response.authResponse.accessToken;
                    $http.post('/register/getData', user_data).then(function (response) {
                        self.user = response.data;
                        console.log(self.user);
                        if(self.user.emai){
                          var data = {};
                          data.email = self.user.emai;
                          data.password = 'social'
                          login(data)
                        }
                        else{
                          alert('plz provide valid email id and password')
                        }
                    }, function (response) {
                        self.handleError(response);
                    });

                }
                else {
                    self.fb_button = true;
                    FB.login();
                }
            });

        }
  }


}());













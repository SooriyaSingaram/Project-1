var options = require('../env'),
    request = require('request'),
    http = require("https");


var getResults = function (reqs, type, payload, cb) {
    try {
        options.method = type;
        if (reqs.params.id) {
            options.path = "/api/v1/conferences/" + reqs.params.id;
        } else {
            options.path = "/api/v1/conferences/";

        }
        var req = http.request(options, (res) => {
            var chunks = [];
            res.on("data", (chunk) => {
                chunks.push(chunk)
            })
            res.on('end', () => {
                return cb(undefined, {
                    headers: res.headers,
                    statusCode: res.statusCode,
                    content: Buffer.concat(chunks).toString()
                });
            })
        })
        if (payload) {
            req.write(payload)
        }
        req.end();
    } catch (e) {
        console.log(e)
        return cb(e.toString())
    }
}


module.exports = {
    getResults: getResults
}
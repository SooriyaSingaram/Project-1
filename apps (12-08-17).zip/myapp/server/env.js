 var options = {
        "hostname": "www.bigmarker.com",
        "port": null,
        "headers": {
            "api-key": "8c1708b7ecf542da8161"
        }
    };
    module.exports = options;
